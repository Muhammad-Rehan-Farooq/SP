import sys
import psutil
import time
import os

if len(sys.argv)<2:
    print ("No command line Arguments")
else:
    for i in range(1,len(sys.argv)):
        try:
            id=int(sys.argv[i])
            if psutil.pid_exists(id):
                print ("Process ID : ", psutil.Process(pid=id)._pid)
                print ("Process Name : ",psutil.Process(pid=id).name())
                print ("Process Status : ",psutil.Process(pid=id).status())
                print ("Process Parent ID : ",psutil.Process(pid=id).ppid())
                print ("Process Parent Name : ",psutil.Process(pid=id).parent().name())
                print ("Process Creation Time : ",time.ctime(psutil.Process(pid=id).create_time()))
                print ("Memory Info : ",psutil.Process(pid=id).memory_info())
                print 
                print ("Opened files by Process : ",psutil.Process(pid=id).open_files())
            else:
                print ("Process not exist against PID = ",id)
        except:
            print ("Invalid ID ! ID must be in integers...")
            exit()